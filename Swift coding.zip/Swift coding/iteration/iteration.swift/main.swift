//
//  main.swift
//  iteration
//
//  Created by LUCHITH DILPAHAN THEJITHA RAMA RAMANAYAKE PATHIRANNEHELAGE on 22/10/2025.
//

import Foundation

// Sample array
let fruits = ["Apple", "Banana", "Cherry", "Date", "Elderberry"]

// Part 1: Iterate with index and item
print("Iterating with index and item:")
for (index, fruit) in fruits.enumerated() {
    print("Index \(index): \(fruit)")
}

print("\nLoop from a to b exclusive of b:")

// Part 2: Loop from a to b (exclusive of b)
let a = 1
let b = 4

for index in a..<b {
    print("Item at index \(index): \(fruits[index])")
}

