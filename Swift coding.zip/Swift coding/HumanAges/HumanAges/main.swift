//
//  main.swift
//  HumanAges
//
//  Created by LUCHITH DILPAHAN THEJITHA RAMA RAMANAYAKE PATHIRANNEHELAGE on 22/10/2025.
//

import Foundation

struct HumanAges: Collection {
    // Backing store
    private var ages: [Int] = []

    // MARK: - Collection conformance
    var startIndex: Int { ages.startIndex }
    var endIndex: Int { ages.endIndex }

    subscript(position: Int) -> Int {
        ages[position]
    }

    func index(after i: Int) -> Int {
        ages.index(after: i)
    }

    // MARK: - Public age-safe methods
    mutating func append(_ age: Int) {
        guard isValidAge(age) else { return }
        ages.append(age)
    }

    mutating func insert(_ age: Int, at index: Int) {
        guard isValidAge(age), ages.indices.contains(index) || index == ages.endIndex else { return }
        ages.insert(age, at: index)
    }

    mutating func remove(at index: Int) -> Int {
        return ages.remove(at: index)
    }

    // Optional: expose count
    var count: Int {
        return ages.count
    }

    // Optional: expose all ages
    var allAges: [Int] {
        return ages
    }

    // MARK: - Validation
    private func isValidAge(_ age: Int) -> Bool {
        return (0...120).contains(age)
    }
}
var people = HumanAges()

people.append(25)
people.append(34)
people.append(-5)     // Ignored
people.append(130)    // Ignored
people.append(120)    // Accepted

print("Ages:", people.allAges)
// Output: Ages: [25, 34, 120]

for age in people {
    print("Person is \(age) years old.")
}
