//
//  main.swift
//  10 green bottles
//
//  Created by LUCHITH DILPAHAN THEJITHA RAMA RAMANAYAKE PATHIRANNEHELAGE on 22/10/2025.
//

func greenBottles(_ n: Int) -> String {
    guard n > 0 else { return "" }
    let verse = "\(n) green bottles hanging on the wall, \(n) green bottles hanging on the wall, and if one green bottle should accidentally fall, there'd be \(n - 1) green bottles hanging on the wall."
    let separator = n > 1 ? "\n" : ""
    return verse + separator + greenBottles(n - 1)
}
print(greenBottles(3))


