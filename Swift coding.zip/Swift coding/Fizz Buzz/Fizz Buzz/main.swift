//
//  main.swift
//  Fizz Buzz
//
//  Created by LUCHITH DILPAHAN THEJITHA RAMA RAMANAYAKE PATHIRANNEHELAGE on 22/10/2025.
//

for number in 1...301 {
    if number % 15 == 0 {
        print("Fizz Buzz")
    } else if number % 3 == 0 {
        print("Fizz")
    } else if number % 5 == 0 {
        print("Buzz")
    } else {
        print(number)
    }
}
for number in 1...301 {
    let numberStr = String(number)
    let contains3 = numberStr.contains("3")
    let contains5 = numberStr.contains("5")

    if (number % 15 == 0) || (contains3 && contains5) {
        print("Fizz Buzz")
    } else if (number % 3 == 0) || contains3 {
        print("Fizz")
    } else if (number % 5 == 0) || contains5 {
        print("Buzz")
    } else {
        print(number)
    }
}


