//
//  main.swift
//  LSP
//
//  Created by LUCHITH DILPAHAN THEJITHA RAMA RAMANAYAKE PATHIRANNEHELAGE on 22/10/2025.
//

import Foundation

class LiskovPhraseMaker {
    
    private var type: String = "S"
    private var subtype: String = "T"
    
    // Store all type-subtype pairs in a Set to avoid duplicates
    private var typeSubtypePairs: Set<Pair> = []
    
    // Pair structure that conforms to Hashable for use in Set
    struct Pair: Hashable {
        let type: String
        let subtype: String
    }
    
    func setTypeAndSubtype(type: String, subtype: String) {
        self.type = type
        self.subtype = subtype
        
        let newPair = Pair(type: type, subtype: subtype)
        typeSubtypePairs.insert(newPair) // Adds only if not duplicate
    }
    
    func modifiedLiskovPhrase() -> String {
        return "If \(subtype) is a subtype of \(type), then objects of type \(type) may be replaced with objects of type \(subtype) without altering the correctness of the program."
    }
    
    func listAllPairs() -> [Pair] {
        return Array(typeSubtypePairs)
    }
    
    func printAllPairs() {
        print("\nStored type-subtype pairs:")
        for pair in typeSubtypePairs {
            print("Type: \(pair.type), Subtype: \(pair.subtype)")
        }
    }
    
    func deletePair(type: String, subtype: String) {
        let pairToDelete = Pair(type: type, subtype: subtype)
        if typeSubtypePairs.remove(pairToDelete) != nil {
            print("Deleted pair: (\(type), \(subtype))")
        } else {
            print("Pair not found: (\(type), \(subtype))")
        }
    }
    
    // Advanced: Get all transitive subtypes of a given type
    func getAllSubtypes(of baseType: String) -> Set<String> {
        var result: Set<String> = []
        var toProcess: [String] = [baseType]
        
        while !toProcess.isEmpty {
            let current = toProcess.removeFirst()
            for pair in typeSubtypePairs {
                if pair.type == current && !result.contains(pair.subtype) {
                    result.insert(pair.subtype)
                    toProcess.append(pair.subtype)
                }
            }
        }
        return result
    }
}
import Foundation

let phraseMaker = LiskovPhraseMaker()

// Add multiple pairs
phraseMaker.setTypeAndSubtype(type: "Feline", subtype: "Lion")
print(phraseMaker.modifiedLiskovPhrase())

phraseMaker.setTypeAndSubtype(type: "Vehicle", subtype: "Motor Vehicle")
phraseMaker.setTypeAndSubtype(type: "Motor Vehicle", subtype: "Car")
phraseMaker.setTypeAndSubtype(type: "Car", subtype: "Hatchback")

// Add duplicate (should be ignored)
phraseMaker.setTypeAndSubtype(type: "Car", subtype: "Hatchback")

// Print all stored pairs
phraseMaker.printAllPairs()

// Delete a pair
phraseMaker.deletePair(type: "Feline", subtype: "Lion")

// Print again to see deletion effect
phraseMaker.printAllPairs()

// Advanced: Get all subtypes of "Vehicle"
let vehicleSubtypes = phraseMaker.getAllSubtypes(of: "Vehicle")
print("\nAll transitive subtypes of Vehicle: \(vehicleSubtypes.sorted())")



