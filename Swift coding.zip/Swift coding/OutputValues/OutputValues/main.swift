//
//  main.swift
//  OutputValues
//
//  Created by LUCHITH DILPAHAN THEJITHA RAMA RAMANAYAKE PATHIRANNEHELAGE on 22/10/2025.
//

import Foundation

// Declare variables
var myInteger: Int = 42
var myFloat: Float = 3.14
let myString: String = "Hello, Swift!"

// Output values to the log
print("Integer value: \(myInteger)")
print("Float value: \(myFloat)")
print("String value: \(myString)")


